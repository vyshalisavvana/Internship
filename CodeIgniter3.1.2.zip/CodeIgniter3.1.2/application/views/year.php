<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html>
<head>
	<title>Details</title>
	<style type="text/css">
		.text
		{
			text-align: center;
		}
		h1
		{
			text-align: center;
			font-family: serif;
			font-style: inherit;
			text-decoration: underline;
		}
#id
{
	font-family: serif;
	font-style: inherit;
}
	</style>
</head>
<body bgcolor="#B0E0E6">
	<div class="text">
		<h1>Year</h1>
<form action="" method="post">		
	<select name="y">
	    <option value="">Choose your year</option>
	    <option value="10">1</option>
	    <option value="20">2</option>
	    <option value="30">3</option>
	    <option value="40">4</option>
	</select>
	<br><br>
<input class="button" type="submit" name="buttony" value="View"></form><br><br>
<a href="<?php echo base_url();?>index.php/connection/">Logout</a>	
</div>

</body>
</html>
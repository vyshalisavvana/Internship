<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Departments</title>
	<style type="text/css">
		span
		{
			font-family: serif;
			font-style: inherit;
			font-weight: bold;
			color:blue;
		}
		/*div
		{
			position: absolute;
			top: 30%;
			left:40%;
		}*/
		h1
		{
			font-family: serif;
			font-style: inherit;
			text-decoration: underline;
		}
		#new
		{
			font-family: serif;
			font-style: inherit;
				font-size: 15px;
		}
table, th, td {
  border: 1px solid black;
}
td{
	text-align: center;
	
}
table
{
	position: absolute;
	top: 80px;
}
</style>
</head>
<body bgcolor="		#D8BFD8">
<h1>DEPARTMENT</h1>
<!--<?php echo "<pre>";print_r($books);echo "</pre>";?>-->
  		<table style="width:50%">		

  <tr>
    <th>Department</th>
    <th>Department ID</th> 
    <th>Action</th> 

      </tr>
  		  	<?php
  			foreach( $lists as $value)
  			{

  			?>		

  <tr>
    <td ><?php echo $value->name;?></td>
    <td><?php echo $value->ddid;?></td> 
   <td><a href="<?php echo base_url();?>index.php/connection/deptedit/<?php echo $value->ddid;?>">EDIT</a>&nbsp;&nbsp;
   	<a href="<?php echo base_url();?>index.php/connection/deptdelet/<?php echo $value->ddid;?>" onclick="javascript:return confirm('are u sure ??');">DELETE</a>
  </tr>
  


  			<div id="new">
<!--<span>Name of the book: </span><?php echo $value->name;?><br>
<span>Author: </span><?php echo $value->author;?><br>
--><br>
</div>

<br>

  			<?php 
  			}
  		 ?>
</table>

<br><br>	
<a href="<?php echo base_url();?>index.php/connection/sup">Back</a>
</body>
</html>
<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>register</title>
	<style type="text/css">
        body
        {
            /*background: url(<?php echo base_url('/images/admin.jpg');?>)  no-repeat;
         background-size:cover; */
            background-color:       #87CEFA;
        }
	</style>
</head>
<body >
	<div class="align">
        <h1>Add your details</h1>
       
 <form name="add_form" method="post" action="">
        Name of book:<input class="text" type="text" name="bookname" required="required" ><br><br>
        Author:<input class="text" type="text" name="author" required="required"><br>
       
        	<br>
        	Branch:
        	<select name="branch" id="branch" onchange="get_dname()">
       <?php    
    foreach($edt as $value)
    {
    ?>
    <option value="<?php echo $value->name;?>" ><?php echo  $value->name; ?></option>
    <?php
    }
    ?>
            </select>
                <br><br>
                <!--branch:<input type="text" name="branch" id="branch"><br><br>-->

               <!-- <input type="hidden" name="dname" id="dname" value="">-->

        Year:<select name="y">
            <option value="">Choose your year</option>
            <option value="10">1</option>
            <option value="20">2</option>
            <option value="30">3</option>
            <option value="40">4</option>
        </select>

        <input type="submit" name="add_it" value="Add">	
</form><br>
</div>

<!--<script>
        function get_dname()
        {
            var dname_opt = document.getElementById("branch");
            var dname = dname_opt.options[dname_opt.selectedIndex].text;

           // alert(dname);
           document.getElementById("dname").value = dname;
        }
</script>-->

</body>
</html>
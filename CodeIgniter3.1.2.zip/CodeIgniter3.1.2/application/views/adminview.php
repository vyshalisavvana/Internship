<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>books</title>
	<style type="text/css">
        body
	    {
	     background: url(<?php echo base_url('/images/book.jpg');?>)  no-repeat;
	     background-size:cover; 
        	text-align: center;
        }
		span
		{
			font-family: serif;
			font-style: inherit;
			font-weight: bold;
			color:blue;
		}
		/*div
		{
			position: absolute;
			top: 30%;
			left:40%;
		}*/
		h1
		{
			font-family: serif;
			font-style: inherit;
			text-decoration: underline;
		}
		#new
		{
			font-family: serif;
			font-style: inherit;
			font-size: 15px;
			
		}
		table
		{
			position: absolute;
			left:25%;
		}
table, th, td {
  border: 1px solid black;
}
td{
	text-align: center;
	
}
.ht
{
	position: absolute;
	top: 30%;
	left:45%;
}
.dt
{
	position: absolute;
	top: 30%;
	left:55%;
}
</style>
</head>
<body>




<h1>BOOK</h1>
<?php //echo "<pre>";print_r($books);echo "</pre>";?>
  		  

  		  <table style="width:50%">	
  		  	<tr>
    <th>Name of the book</th>
    <th>Author</th> 
    <th>Action</th> 

      </tr>
  		  	<?php
  			foreach( $admins as $value)
  			{

  			?>
  		
  					

  

  <tr>
    <td ><?php echo $value->name;?></td>
    <td><?php echo $value->author;?></td> 
    <td><a href="<?php echo base_url();?>index.php/connection/bookedit/<?php echo $value->bid;?>">EDIT</a>&nbsp;&nbsp;
   	<a href="<?php echo base_url();?>index.php/connection/bookdelet/<?php echo $value->bid;?>" onclick="javascript:return confirm('are u sure ??');">DELETE</a>
  </tr>
  


  			

  			<?php 
  			}
  		 ?>
  		 </table>

  		 <div id="new">
<!--<span>Name of the book: </span><?php echo $value->name;?><br>
<span>Author: </span><?php echo $value->author;?><br>
--><br>
</div>

<br>


<a  class="ht" href="<?php echo base_url();?>index.php/connection/addbook/">ADD</a>&nbsp;	
<a class="dt" href="<?php echo base_url();?>index.php/connection/sup">Back</a>
</body>
</html>
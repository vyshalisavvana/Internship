<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>login for library</title>
	<style type="text/css">
	@import"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css";
	    body
	    {
	     background: url(<?php echo base_url('/images/image.jpg');?>)  no-repeat;
	     background-size:cover; 
	     

	    }
		h1
		{
			text-decoration:underline;
			font-family: serif;
			font-style: inherit; 
			color: white;
		}
		.textbox i
{
	width:26px;
	float: left;
	text-align: center;

}
i
{
	color: white;
	text-align: center;
}
.button
{
	width: 10%;
	align-items: center;
	background: none;
	border: 2px solid;
	color:white;
	padding:5px;
	font-size: 20px;
	margin:5px;
}
.textbox
{
	font-family: serif;
	font-style: inherit;
	text-align: center;
}
.class
{
	position: absolute;
	/*top: 35%;*/
	left:80%;
}
.button
{
	position: absolute;
	top:25%;
	left:83%;
}


	</style>
</head>
<body>
	<div class="class">
	<h1>LOGIN</h1>
<?php
if($this->session->flashdata("error")!="")
{
	echo $this->session->flashdata("error");
}
?>

<form action="" method="post">	
<div class="textbox">
	<i class="fa fa-user"></i>
	<input placeholder="Username" type="text" name="Username" required="required">
</div>
<br>
<div class="textbox">
	<i class="fa fa-lock"></i>
	<input placeholder="Password" type="Password" name="Password" required="required">
</div>
<br>
</div>
<input class="button" type="submit" name="button" value="Login"></form>

</body>
</html>
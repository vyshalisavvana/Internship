<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
	<head>
		<title>Book</title>
	</head>
	
	<body>
		<h1>BOOKS</h1>
		
		<!--<?php
			//echo $sampletext;
			
			//echo "<pre>";print_r($holidays);echo "</pre>";
			//$holidays["hid"];
			//$holidays->hid;
			
			//foreach($book as $value)
			{
				//echo "<pre>";print_r($value);echo "</pre>";
				
				//echo "<br />BID    ======= ".$value->bid;
				//echo "<br />YYID   ======= ".$value->yyid;
				//echo "<br />DeptID ======= ".$value->deptid;
				//echo "<br />Dname  ======= ".$value->dname;
				//echo "<br />name   ======= ".$value->name;
				//echo "<br />author ======= ".$value->author;
				//echo "<hr />";
			}
		?>
		
		<form name="form2" id="form2" method="post" action="">
			Name: <input type="text" name="dname" id="dname" />
			
			<input type="submit" name="submit_btn" id="submit_btn" value="Submit" />
		</form>-->
		
		
	</body>
</html>
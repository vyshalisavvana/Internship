<!DOCTYPE html>
<html>
<head>
	<title>details of departments</title>
</head>
<body><?php
session_start();
$conn=mysqli_connect("localhost","root","","library");

 $sqlquery="SELECT ddid,name from department" ;

$result=$conn->query($sqlquery);
?>
<h1>List of Departments</h1>
<a href="depart_add.php">Add</a><br><br>
<?php
while($row= $result->fetch_assoc())
{
//print_r($row);

	?>
	<table style="width:50%">	
  		  	<tr>
    <th>department</th>
    <th>department id</th> 

      </tr>

     <tr>
    <td ><?php echo $value->name;?></td>
    <td><?php echo $value->ddid;?></td> 
    
  </tr>
   
	<div id="new">
	<!--<span> department: </span><?php echo  $row['name'];?><br>
<span>department id: </span><?php echo   $row['ddid'];?><br>-->
<a href="depart_edit.php?ddid=<?php echo $row['ddid'];?>">Edit</a>&nbsp;
<a href="depart_delete.php?ddid=<?php echo $row['ddid'];?>">Delete</a>
<br><br>
</div>

<?php
}
?>
 </table>
<br>
<a href="department.php">Back</a>

</body>
</html>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Department</title>
	<style type="text/css">
		body
		{
			/*background: url(<?php echo base_url('/images/admin.jpg');?>)  no-repeat;
	     background-size:cover; */
			background-color:		#87CEFA;
		}
		.look
		{
			text-align: center;
		}
		h1
		{
			font-family: serif;
			font-style: inherit;
			text-align: center;
			text-decoration: underline;
		}
		.button
{
	width: 10%;
	align-items: center;
	background: none;
	border: 2px solid;
	color:black;
	padding:5px;
	font-size: 20px;
	margin:5px;
}
a{
	color:black;
	font-weight: bolder;
}
	</style>
</head>
<body>
<div class="look">
	<form action="" method="post">	
	<h1>Admin page</h1>
	<!--<input class="button" type="submit" name="dept" value="CSE">
	<input class="button" type="submit" name="dept" value="ECE">
	<input class="button" type="submit" name="dept" value="EEE">
	<br><br>-->
	<?php //echo "<pre>";print_r($depts);echo "</pre>";?>
	<select name="dept">
	<?php	foreach($depts as $value)
	{
	?>
	<option value="<?php echo $value->ddid;?>" ><?php echo  $value->name; ?></option>
	<?php
	}
	?>
	</select><br><br>
	<input class="button" type="submit" name="button" value="View"><br><br>
	<a href="<?php echo base_url();?>index.php/connection/adddept">Add Department</a><br><br>
	

	<!--<a href="depart_delete.php">Delete</a><br><br>
	<a href="depart_edit.php">Edit</a>-->
</form>
<a href="<?php echo base_url();?>index.php/connection/deptlist">List of Departments</a><br><br>
<a href="<?php echo base_url();?>index.php/connection/logout">Logout</a>

</div>
</body>
</html>
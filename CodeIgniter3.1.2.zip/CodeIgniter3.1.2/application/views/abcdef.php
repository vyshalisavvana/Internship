<html>
	<head>
		<title>Books</title>
	</head>
	
	<body>
		<h1>Books</h1>
		
		<?php
			//echo $sampletext;
			
			//echo "<pre>";print_r($holidays);echo "</pre>";
			//$holidays["hid"];
			//$holidays->hid;
			
			foreach($bookdetail as $value)
			{
				//echo "<pre>";print_r($value);echo "</pre>";
				
				echo "<br />BOOK ID ======= ".$value->bid;
				echo "<br />YYID ======= ".$value->yyid;
				echo "<br />DEPTID ======= ".$value->deptid;
				echo "<br />DNAME ======= ".$value->dname;
				echo "<br />NAME ======= ".$value->name;
				echo "<br />AUTHOR ======= ".$value->author;
				echo "<hr />";
			}
		?>
		
		<form name="form2" id="form2" method="post" action="">
			Name: <input type="text" name="name" id="name" />
			
			<input type="submit" name="submit_btn" id="submit_btn" value="Submit" />
		</form>
		
		
	</body>
</html>
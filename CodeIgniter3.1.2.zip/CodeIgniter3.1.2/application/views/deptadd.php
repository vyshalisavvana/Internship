<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>department add</title>
	<style type="text/css">
		h1
		{
			text-decoration:underline; 
		}
	</style>
</head>
<body bgcolor="#E0FFFF">
	<div class="align">
        <h1>Add Department Details</h1>
       
 <form name="add_form" method="post" action="">
        	Branch: <input type="text" name="branch" placeholder="Branch" required="required" ><br><br>
            Branch id: <input type="text" name="branchid" placeholder="Branchid" required="required" ><br><br>

        <input type="submit" name="add_it" value="Add">	
</form><br>
</div>
<a href="<?php echo base_url();?>index.php/connection/sup">Back</a>
</body>
</html>
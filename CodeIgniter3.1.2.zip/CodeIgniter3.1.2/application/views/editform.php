<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		h1
		{
			text-decoration:underline; 
		}
	</style>
	<title>edit</title>
</head>
<body bgcolor="	#FFDAB9">
	<h1>Edit Department Details</h1> 
<form name="edit_form" method="post" action="">

	department:<input type="text" name="dname" id="dname" value="<?php echo $edt[0]->name;?>"><br><br>
	id:<input type="text" name="did" id="did" value="<?php echo $edt[0]->ddid;?>"><br><br>
	<input type="submit" name="update_btn" value="Update">
</form>
</body>
</html>
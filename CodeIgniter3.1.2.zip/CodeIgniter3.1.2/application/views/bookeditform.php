<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>edit book</title>
</head>
<body bgcolor="#F0E68C">
<form name="edit_form" method="post" action="">

	Year:<select name="year" id="year">
		<option value="10" <?php if($book[0]->yyid == 10) echo "selected"; ?>>1</option>
		<option value="20" <?php if($book[0]->yyid == 20) echo "selected"; ?>>2</option>
		<option value="30" <?php if($book[0]->yyid == 30) echo "selected"; ?>>3</option>
		<option value="40" <?php if($book[0]->yyid == 40) echo "selected"; ?>>4</option>
	</select> <br><br>
		Department:<select name="department" id="department">
	<?php	
	foreach($edt as $value)
	{
	?>
	<option value="<?php echo $value->name;?>" <?php if($book[0]->dname==$value->name) echo "selected";?>><?php echo  $value->name; ?></option>
	<?php
	}
	?>
	</select><br><br>
	<!--department:<input type="text" name="department" id="department" value="<?php echo $book[0]->dname;?>"><br><br>-->
	Name of the book:<input type="text" name="bname" id="bname" value="<?php echo $book[0]->name;?>" ><br><br>
	Author:<input type="text" name="bauthor" id="bauthor" value="<?php echo $book[0]->author;?>"><br><br>
	<input type="submit" name="update_btn" value="Update">
</form>
</body>
</html>
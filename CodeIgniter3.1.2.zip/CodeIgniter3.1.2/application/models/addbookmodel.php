<?php
    class addbookmodel extends CI_Model
    {
            
        public function bkadd($year,$department,$name,$author)
        {
           // $ddid=$_POST['branchid'];
          // $name=$_POST['branch'];
            //$detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name ")->result();
          $value=$this->db->query("SELECT ddid from department where name='$department'")->result();

          $ddid = $value[0]->ddid;

                //$detail=$this->db->query("INSERT into book(yyid,dname,deptid,name,author) values('$year','$department','$value','$name','$author')  ");
                $detail=$this->db->query("INSERT into book(yyid,deptid,dname,name,author) values('$year','$ddid','$department','$name','$author')  ");
//value=$this->db->query("SELECT ddid from department where name='$department'");
               // $detail=$this->db->query("INSERT into book(deptid)values('$value')");
               // $detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name where book.dname='name'")->result();
            //echo $this->db->last_query();
            
            //$value=array()
            return $detail;
        }
}
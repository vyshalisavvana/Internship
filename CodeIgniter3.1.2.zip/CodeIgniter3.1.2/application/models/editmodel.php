<?php
    class editmodel extends CI_Model
    {
            
        public function edit($ddid,$dname,$id)
        {
           // $ddid=$_POST['branchid'];
          // $name=$_POST['branch'];
            //$detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name ")->result();
                $detail=$this->db->query("UPDATE department SET name='$dname', ddid='$ddid' WHERE ddid='$id' ");
                $detail=$this->db->query(" UPDATE book set dname='$dname',deptid='$ddid' where deptid='$id'");
               // $detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name where book.dname='name'")->result();
            //echo $this->db->last_query();
            
            //$value=array()
           // return $detail;
                if($detail){
                return true;}
        }

    }
?>
<?php
	class bookmodel extends CI_Model
	{
			
        public function bookpage($year)
        {
        	$bookdetail=$this->db->query("SELECT  book.yyid,book.deptid,book.name,book.author from book join year on book.yyid=year.yid join department on book.deptid=department.ddid where book.yyid='".$this->session->userdata("yid")."' and book.deptid='".$this->session->userdata("dept")."'")->result();
        	//echo $this->db->last_query();
        	return $bookdetail;

        }

       /* function one_book($yyid)
		{
			$book= $this->db->query("SELECT bid,yyid,deptid,dname,name,author FROM book WHERE yyid = '$yyid'")->result();
			
			return $book;
		}*/

	}
?>
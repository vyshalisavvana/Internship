<?php
	class deptmodel extends CI_Model
	{
			
        public function depart()
        {
        	$departdetails=$this->db->query("SELECT ddid,name from department")->result();
        	//echo $this->db->last_query();
        	return $departdetails;

        }


        function department($dname)
        {
                return $this->db->query("SELECT ddid, name froM department WHERE ddid = '$dname'")->result();
        }

        function dept($ddid)
        {
               return $this->db->query("SELECT ddid, name froM department WHERE ddid = '$ddid'")->result(); 
        }

	}
?>
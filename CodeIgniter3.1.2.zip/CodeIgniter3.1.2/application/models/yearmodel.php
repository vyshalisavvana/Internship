<?php
	class yearmodel extends CI_Model
	{
			
        public function yearpage($year)
        {
        	$yeardetail=$this->db->query("SELECT yid,yearst FROM year where yid='$year'")->result();
        	//echo $this->db->last_query();
        	return $yeardetail;

        }

	}
?>
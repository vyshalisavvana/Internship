<?php
    class admodel extends CI_Model
    {
            
        public function ad()
        {
            //$detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name ")->result();
                $detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name where book.deptid=department.ddid")->result();
               // $detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name where book.dname='name'")->result();
            //echo $this->db->last_query();
            return $detail;

        }

    }
?>
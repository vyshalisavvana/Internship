<?php
    class bookeditmodel extends CI_Model
    {
            
        public function bkedit($department,$name,$author,$bid,$year)
        {
           // $ddid=$_POST['branchid'];
          // $name=$_POST['branch'];
            //$detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name ")->result();
               $det=$this->db->query("SELECT ddid,name from department where name='$department'")->result();
                $ddid = $det[0]->ddid;

                $detail=$this->db->query("UPDATE book SET dname='$department',name='$name',author='$author',yyid='$year',deptid='$ddid' WHERE bid='$bid'  ");
               // $detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name where book.dname='name'")->result();
            //echo $this->db->last_query();
            
            //$value=array()
            return $detail;
        }


        function bookdetails($bid)
        {
            $bookdetail=$this->db->query("SELECT yyid,dname,name,author from book where bid='$bid'")->result();
            return $bookdetail;
        }

    }
?>
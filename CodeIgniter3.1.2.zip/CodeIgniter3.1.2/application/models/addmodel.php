<?php
    class addmodel extends CI_Model
    {
            
        public function add($did,$name)
        {
           // $ddid=$_POST['branchid'];
          // $name=$_POST['branch'];
            //$detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name ")->result();
                $detail=$this->db->query("INSERT into department (ddid,name) values('$did','$name')  ");
               // $detail=$this->db->query("SELECT book.bid,book.yyid,book.deptid,book.dname,book.name,book.author from book join department on book.dname=department.name where book.dname='name'")->result();
            //echo $this->db->last_query();
            
            //$value=array()
            return $detail;
        }

    }
?>
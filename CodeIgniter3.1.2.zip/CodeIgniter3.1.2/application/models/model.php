<?php
	class HomeModel extends CI_Model
	{
			
        public function loginpage($user,$pwd)
        {
        	$login=$this->db->query("SELECT id,did,utype,Username,password FROM loginpage where Username='$user'and Password='$pwd'");
        	return $login;

        }

	}
?>
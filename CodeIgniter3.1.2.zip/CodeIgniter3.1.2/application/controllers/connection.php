
<?php
defined('BASEPATH')OR exit('No direct script access allowed');
class connection extends CI_Controller
{



	public function index()
	{

		if($this->session->userdata("uid")!="")
		{
			redirect(base_url()."index.php/connection/sup");
			exit();
		}


		$this->load->model("HomeModel");

		$this->load->view('login');
		if($this->input->post()!=""&& $this->input->post("button")!=""&& $this->input->post("button")=="Login")
		{
			$user=$this->input->post("Username");
			$pwd=$this->input->post("Password");
			$login=$this->HomeModel->loginpage($user,$pwd);
			if($login)
			{
				//echo "<pre>";print_r($login);exit;

				//$_SESSION['uid']=1;
				$this->session->set_userdata("sup",$login[0]->utype);
				$this->session->set_userdata("uid",$login[0]->id); // create a session
				$this->session->set_userdata("dept",$login[0]->did);
				 if(($this->session->userdata("sup"))=="s")
			{
				redirect(base_url()."index.php/connection/sup");
			}


				//$this->session->userdata("uid"); // Use a session
				//$this->session->unset_userdata("uid"); // Unset a particular session

				// $this->session->sess_destroy(); // Destroy all the sessions

				else
					{redirect(base_url()."index.php/connection/year");}
			}
			else
			{
				//echo "error";

				$this->session->set_flashdata("error","Incorrect login credentials.");

				redirect(base_url());
			}
			/*if($this->session->userdata("sup")==NULL)
			{
				redirect(base_url());
			}
			else
			{
				redirect(base_url()."index.php/connection/sup");
			}*/
			

		}
	}
	public function year()
	{
		$this->load->model("yearmodel");
		$this->load->view('year');
		if($this->input->post()!=""&& $this->input->post("buttony")!=""&& $this->input->post("buttony")=="View")
		{
			$yid=$this->input->post("y");
			$year=$this->yearmodel->yearpage($yid);
			if($year)
			{

				$this->session->set_userdata("yid",$year[0]->yid);
				redirect(base_url()."index.php/connection/book");
			}

		}
	}
	public function book()
	{

	/*	$book = $this->HomeModel->book();
		$data["book"] = $book;
		$data["sampletext"] = "THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE ";
		
		
		if($this->input->post()!="" && $this->input->post("submit_btn")!="" && $this->input->post("submit_btn")=="Submit")
		{
			$yyid = $this->security->xss_clean(addslashes(strip_tags(trim($this->input->post("yyid")))));
			
			echo $yyid;
			
			$yyid = $this->HomeModel->one_holiday($yyid);
			
			echo "<pre>";print_r($yyid);echo "</pre>";
		}
*/
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}


		$this->load->model("bookmodel");
		
		$books = $this->bookmodel->bookpage($this->session->userdata("yid"));
		 $data["books"] = $books;

       // $this->load->view('abcdef');
		//print_r($books);

		//if($this->input->post()!=""&& $this->input->post("buttonx")!=""&& $this->input->post("buttonx")=="View")
			//$this->load->view("abcdef",$data);

		//redirect(base_url()."index.php/connection/logout");
		$this->load->view('book',$data);

	}
	public function sup()
	{

		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}

        $this->load->model("deptmodel");
       $this->load->model("adminmodel");
        //$this->load->model("admodel");
        
		$depts = $this->deptmodel->depart();
		$data["depts"] = $depts;
        $this->load->view('department',$data);
		if($this->input->post()!=""&& $this->input->post("button")!=""&& $this->input->post("button")=="View")
		{
			$did=$this->input->post("dept");
			//$depart=$this->adminmodel->admin($did);
			//$depart=$this->admodel->ad($did);
			$depart=$this->deptmodel->department($did);


			if($depart)
			{
				$this->session->set_userdata("did",$depart[0]->ddid);
				redirect(base_url()."index.php/connection/adminbook");
				
			}
		}
	}
	public function adminbook()
	{
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		 $this->load->model("adminmodel");
		//$this->session->set_userdata("did",$dname[0]->name);
		$admins = $this->adminmodel->admin($this->session->userdata("did"));
		//$admins = $this->adminmodel->admin();
		$data["admins"] = $admins;
		$this->load->view('adminview',$data);
	}
	public function adddept()
	{
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		$this->load->model("addmodel");
		if($this->input->post()!=""&& $this->input->post("add_it")!=""&& $this->input->post("add_it")=="Add")
		{
			
			$branchid=$this->input->post("branchid");
			$branch=$this->input->post("branch");
			$branchadd=$this->addmodel->add($branchid,$branch);

			if($branchadd)
			{

				//$this->session->set_userdata("yid",$year[0]->yid);
				redirect(base_url()."index.php/connection/sup");
			}
		}
		//$adds = $this->addmodel->add();
		//$data["adds"] = $adds;
		$this->load->view('deptadd');
	}
	public function deptlist()
	{
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		$this->load->model("deptmodel");
		$lists = $this->deptmodel->depart();
		$data["lists"] = $lists;
		$this->load->view('deptlist',$data);
	}


	public function deptdelet($ddid)
	{ 
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		$this->load->model("deletmodel");
		$dlt = $this->deletmodel->delet($ddid);
		$data["dlt"] = $dlt;
		redirect(base_url()."index.php/connection/deptlist");
		//$this->load->view('deptlist',$data);
	}
	public function deptedit($ddid)
	{ 
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		$this->load->model("editmodel");
		$this->load->model("deptmodel");
		$edt = $this->deptmodel->dept($ddid);
		$data["edt"] = $edt;
		if($this->input->post()!=""&& $this->input->post("update_btn")!=""&& $this->input->post("update_btn")=="Update")
		{
			
			$department=$this->input->post("dname");
			$department_Id=$this->input->post("did");
			$depart_edit=$this->editmodel->edit($department_Id,$department,$ddid);
			
		

			if($depart_edit)
			{

				//$this->session->set_userdata("yid",$year[0]->yid);
				//redirect(base_url()."index.php/connection/editform");
				redirect(base_url()."index.php/connection/deptlist");
		}
	}
		
		$this->load->view('editform',$data);
		//redirect(base_url()."index.php/connection/deptlist");
	}
	public function bookdelet($bid)
	{ 
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		$this->load->model("bookdeletmodel");
		$bkdlt = $this->bookdeletmodel->bkdelet($bid);
		$data["bkdlt"] = $bkdlt;
		redirect(base_url()."index.php/connection/adminbook");
		//$this->load->view('deptlist',$data);
	}
	public function bookedit($bid)
	{ 
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		$this->load->model("bookeditmodel");
		$this->load->model("deptmodel");

		$edt = $this->deptmodel->depart();
		$data["edt"] = $edt;

		$book=$this->bookeditmodel->bookdetails($bid);
		$data["book"]=$book;

		//$edt = $this->bookeditmodel->bkedit($bid,$year,$department,$name,$bauthor);
		//$data["edt"] = $edt;
		if($this->input->post()!=""&& $this->input->post("update_btn")!=""&& $this->input->post("update_btn")=="Update")
		{
			
			$year=$this->input->post("year");
			$department=$this->input->post("department");
			$name=$this->input->post("bname");
			$author=$this->input->post("bauthor");

			$bookdepart_edit=$this->bookeditmodel->bkedit($department,$name,$author,$bid,$year);
			//$edt = $this->bookeditmodel->bkedit($department,$name,$author,$bid,$year);
			//$data["department"] = $edt;
		

			if($bookdepart_edit)
			{

				//$this->session->set_userdata("yid",$year[0]->yid);
				//redirect(base_url()."index.php/connection/editform");
				redirect(base_url()."index.php/connection/adminbook");
			}

		}
		//$edt = $this->bookeditmodel->bkedit($department,$name,$bauthor,$bid,$year);
		//$data["bookdepart_edit"] = $bookdepart_edit;
		$this->load->view('bookeditform',$data);
		//redirect(base_url()."index.php/connection/deptlist");
	}




	public function addbook()
	{
		if($this->session->userdata("uid")=="")
		{
			redirect(base_url());
			exit();
		}
		$this->load->model("addbookmodel");
		$this->load->model("deptmodel");
		$edt = $this->deptmodel->depart();
		$data["edt"] = $edt;
		if($this->input->post()!=""&& $this->input->post("add_it")!=""&& $this->input->post("add_it")=="Add")
		{
			
			$name=$this->input->post("bookname");
			$author=$this->input->post("author");
			$department=$this->input->post("branch");
			$year=$this->input->post("y");
			$bookadd=$this->addbookmodel->bkadd($year,$department,$name,$author);

			if($bookadd)
			{

				//$this->session->set_userdata("yid",$year[0]->yid);
				redirect(base_url()."index.php/connection/adminbook");
			}
		}
		//$adds = $this->addmodel->add();
		//$data["adds"] = $adds;
		$this->load->view('bookadd',$data);
	}


	function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url());
		exit();
	}

}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model("HomeModel");
	}
	
	
	function index()
	{
		$holidays = $this->HomeModel->holidays();
		$data["holidays"] = $holidays;
		$data["sampletext"] = "THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE THIS IS SAMPLE ";
		
		
		if($this->input->post()!="" && $this->input->post("submit_btn")!="" && $this->input->post("submit_btn")=="Submit")
		{
			$uname = $this->security->xss_clean(addslashes(strip_tags(trim($this->input->post("uname")))));
			
			echo $uname;
			
			$holiday = $this->HomeModel->one_holiday($uname);
			
			echo "<pre>";print_r($holiday);echo "</pre>";
		}
		
		$this->load->view("abcdef",$data);
	}
	
	
	function sample()
	{
		$holidays = $this->HomeModel->holidays();
		$data["holidays"] = $holidays;
		
		$this->load->view("home",$data);
	}
	
	
	
}
